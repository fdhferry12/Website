#define RELAY1 27
#define RELAY2 26

String command = "";

void setup() {
  Serial.begin(115200);

  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);


  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);

  Serial.println("=================================");
  Serial.println(" TEST RELAY 2 CHANNEL VIA SERIAL ");
  Serial.println("=================================");
  Serial.println("Perintah yang tersedia:");
  Serial.println("1on    -> Relay 1 ON");
  Serial.println("1off   -> Relay 1 OFF");
  Serial.println("2on    -> Relay 2 ON");
  Serial.println("2off   -> Relay 2 OFF");
  Serial.println("allon  -> Semua relay ON");
  Serial.println("alloff -> Semua relay OFF");
  Serial.println("---------------------------------");
}

void loop() {
  if (Serial.available()) {
    command = Serial.readStringUntil('\n');
    command.trim();   // hapus spasi / enter
    command.toLowerCase();

    if (command == "1on") {
      digitalWrite(RELAY1, LOW);   // relay aktif LOW
      Serial.println("Relay 1 ON");
    }
    else if (command == "1off") {
      digitalWrite(RELAY1, HIGH);
      Serial.println("Relay 1 OFF");
    }
    else if (command == "2on") {
      digitalWrite(RELAY2, LOW);
      Serial.println("Relay 2 ON");
    }
    else if (command == "2off") {
      digitalWrite(RELAY2, HIGH);
      Serial.println("Relay 2 OFF");
    }
    else if (command == "allon") {
      digitalWrite(RELAY1, LOW);
      digitalWrite(RELAY2, LOW);
      Serial.println("Semua Relay ON");
    }
    else if (command == "alloff") {
      digitalWrite(RELAY1, HIGH);
      digitalWrite(RELAY2, HIGH);
      Serial.println("Semua Relay OFF");
    }
    else {
      Serial.println("Perintah tidak dikenal!");
      Serial.println("Gunakan: 1on, 1off, 2on, 2off, allon, alloff");
    }
  }
}