// ============================================================
// PROGRAM GABUNGAN FINAL: ESP32 + MQTT + DWIN + SENSOR + RELAY
// Mode awal MANUAL, kirim DWIN per variabel dengan jeda 10ms
// ============================================================

#include <WiFi.h>
#include <PubSubClient.h>
#include <NewPing.h>
#include <DHT.h>

// -------------------- KONFIGURASI PIN --------------------
#define RELAY1_PIN   27
#define RELAY2_PIN   26
#define DHTPIN       25
#define DHTTYPE      DHT11
#define SOIL1_PIN    34
#define SOIL2_PIN    35
#define TRIG_PIN     19
#define ECHO_PIN     18
#define MAX_DIST     50

// DWIN UART (UART1)
#define DWIN_SERIAL  Serial1
#define RX2_PIN      16
#define TX2_PIN      17

// -------------------- WIFI & MQTT --------------------
const char* WIFI_SSID     = "Polinema Hotspot";      // GANTI
const char* WIFI_PASSWORD = "polinemajoss";   // GANTI
const char* MQTT_BROKER   = "broker.emqx.io";
const int   MQTT_PORT     = 1883;
const char* MQTT_CLIENT   = "ESP32_Greenhouse";

#define TOPIC_STATUS      "tandon/status"
#define TOPIC_PUMP1_CTRL  "tandon/pump1/control"
#define TOPIC_PUMP2_CTRL  "tandon/pump2/control"
#define TOPIC_MODE_CTRL   "tandon/mode"

// -------------------- OBYEK --------------------
WiFiClient espClient;
PubSubClient mqtt(espClient);
NewPing sonar(TRIG_PIN, ECHO_PIN, MAX_DIST);
DHT dht(DHTPIN, DHTTYPE);

// -------------------- MODE & RELAY --------------------
enum Mode { AUTO, MANUAL };
Mode controlMode = MANUAL;   // Mode awal MANUAL

bool relay1State = false;    // false = OFF
bool relay2State = false;

// -------------------- DATA SENSOR --------------------
float suhu = 0.0;
float soil1Persen = 0.0;     // diubah ke float untuk 1 desimal
float soil2Persen = 0.0;     // diubah ke float untuk 1 desimal
float levelAirCm = 0.0;
float waterPercent = 0.0;

// Filter suhu (MA+EMA) dari program MQTT
const int WINDOW_SIZE = 10;
float bufferSuhu[WINDOW_SIZE];
int bufferIndex = 0;
bool bufferPenuh = false;
float emaSuhu = 0.0;
bool emaInit = false;
const float EMA_ALPHA = 0.15;
const float TEMP_OFFSET = -0.1;

// Filter jarak
float filteredDist = 0.0;
bool firstDistReading = true;
const float DIST_ALPHA = 0.1;
const float DIST_EMPTY = 26.4;
const float DIST_OFFSET = 1.03;
const float TANK_T = 21.0;   // tinggi tangki dalam cm, acuan untuk persentase

// -------------------- KALIBRASI SOIL (terbaru) --------------------
const int SOIL1_DRY = 2192, SOIL1_WET = 1600;
const int SOIL2_DRY = 3569, SOIL2_WET = 1530;

// -------------------- BUFFER DWIN --------------------
#define VP_SUHU      0x61
#define VP_SOIL1     0x62
#define VP_SOIL2     0x63
#define VP_LEVELAIR  0x64

unsigned char paketSuhu[8] = {0x5A,0xA5,0x05,0x82, VP_SUHU,0x00,0x00,0x00};
unsigned char paketSoil1[8] = {0x5A,0xA5,0x05,0x82, VP_SOIL1,0x00,0x00,0x00};
unsigned char paketSoil2[8] = {0x5A,0xA5,0x05,0x82, VP_SOIL2,0x00,0x00,0x00};
unsigned char paketLevelAir[8] = {0x5A,0xA5,0x05,0x82, VP_LEVELAIR,0x00,0x00,0x00};

// -------------------- STATE MACHINE UNTUK KIRIM DWIN --------------------
enum DwinSendState {
  IDLE,
  SEND_SUHU,
  SEND_SOIL1,
  SEND_SOIL2,
  SEND_LEVELAIR,
  DONE
};
DwinSendState dwinState = IDLE;
unsigned long lastDwinSendTime = 0;
const unsigned long DWIN_SEND_INTERVAL = 10; // jeda 10ms antar paket

// -------------------- TIMING LAINNYA --------------------
unsigned long lastSensorRead = 0;
const unsigned long SENSOR_INTERVAL = 2000;
unsigned long lastMqttPublish = 0;
const unsigned long MQTT_INTERVAL = 3000;
unsigned long lastMqttReconnect = 0;
const unsigned long MQTT_RECONNECT_INTERVAL = 5000;

bool statusChanged = false;

// ============================================================
// DEKLARASI FUNGSI
// ============================================================
void connectWiFi();
void connectMQTT();
void mqttCallback(char* topic, byte* payload, unsigned int length);
void setPump(int pump, bool state, String source);
void bacaSensor();
void updateDWIN();
void parseDWIN();
void publishStatus();
void autoControl();
float getSpeedOfSound(float tempC);
float readDistance();
float movingAverage(float dataBaru);
float updateEMA(float input);

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);

  // Relay OFF
  pinMode(RELAY1_PIN, OUTPUT);
  pinMode(RELAY2_PIN, OUTPUT);
  digitalWrite(RELAY1_PIN, HIGH);
  digitalWrite(RELAY2_PIN, HIGH);

  // Sensor
  dht.begin();
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Inisialisasi buffer suhu
  float suhuAwal = dht.readTemperature();
  if (!isnan(suhuAwal)) {
    for (int i = 0; i < WINDOW_SIZE; i++) bufferSuhu[i] = suhuAwal;
    bufferPenuh = true;
    emaSuhu = suhuAwal;
    emaInit = true;
  }

  // DWIN UART
  DWIN_SERIAL.begin(115200, SERIAL_8N1, RX2_PIN, TX2_PIN);

  // WiFi & MQTT
  connectWiFi();
  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  connectMQTT();

  Serial.println("=== SYSTEM READY ===");
  Serial.println("Mode awal: MANUAL");
}

// ============================================================
// LOOP UTAMA
// ============================================================
void loop() {
  // 1. MQTT
  if (!mqtt.connected()) {
    unsigned long now = millis();
    if (now - lastMqttReconnect > MQTT_RECONNECT_INTERVAL) {
      connectMQTT();
      lastMqttReconnect = now;
    }
  } else {
    mqtt.loop();
  }

  // 2. Baca sensor & kontrol otomatis
  if (millis() - lastSensorRead >= SENSOR_INTERVAL) {
    lastSensorRead = millis();
    bacaSensor();
    if (controlMode == AUTO) {
      autoControl();
    }
    statusChanged = true;
    // Reset state DWIN agar data baru dikirim
    dwinState = IDLE;
  }

  // 3. Kirim ke DWIN (state machine dengan jeda 10ms)
  updateDWIN();

  // 4. Publish MQTT
  if (millis() - lastMqttPublish >= MQTT_INTERVAL) {
    lastMqttPublish = millis();
    if (statusChanged && mqtt.connected()) {
      publishStatus();
      statusChanged = false;
    }
  }

  // 5. Baca data dari DWIN (setiap loop)
  parseDWIN();
}

// ============================================================
// FUNGSI KONEKSI
// ============================================================
void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println(" connected!");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

void connectMQTT() {
  while (!mqtt.connected()) {
    Serial.print("Connecting to MQTT...");
    if (mqtt.connect(MQTT_CLIENT)) {
      Serial.println(" connected");
      mqtt.subscribe(TOPIC_PUMP1_CTRL);
      mqtt.subscribe(TOPIC_PUMP2_CTRL);
      mqtt.subscribe(TOPIC_MODE_CTRL);
    } else {
      Serial.print("failed, rc=");
      Serial.print(mqtt.state());
      Serial.println(", retry in 2s");
      delay(2000);
    }
  }
}

// ============================================================
// MQTT CALLBACK
// ============================================================
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (unsigned int i = 0; i < length; i++) message += (char)payload[i];
  message.trim();
  Serial.printf("MQTT received [%s]: %s\n", topic, message.c_str());

  if (String(topic) == TOPIC_MODE_CTRL) {
    if (message == "auto") {
      controlMode = AUTO;
      Serial.println("Mode -> AUTO");
      statusChanged = true;
    } else if (message == "manual") {
      controlMode = MANUAL;
      Serial.println("Mode -> MANUAL");
      statusChanged = true;
    }
    return;
  }

  // Perintah relay hanya jika MANUAL
  if (controlMode == MANUAL) {
    if (String(topic) == TOPIC_PUMP1_CTRL) {
      if (message == "on")  setPump(1, true, "MQTT");
      else if (message == "off") setPump(1, false, "MQTT");
    }
    else if (String(topic) == TOPIC_PUMP2_CTRL) {
      if (message == "on")  setPump(2, true, "MQTT");
      else if (message == "off") setPump(2, false, "MQTT");
    }
  } else {
    Serial.println("Mode AUTO - perintah relay MQTT diabaikan.");
  }
}

// ============================================================
// SET POMPA (SATU-SATUNYA GERBANG)
// ============================================================
void setPump(int pump, bool state, String source) {
  bool* currentState = (pump == 1) ? &relay1State : &relay2State;
  int pin = (pump == 1) ? RELAY1_PIN : RELAY2_PIN;

  if (*currentState == state) return;

  *currentState = state;
  digitalWrite(pin, state ? LOW : HIGH);   // Active LOW
  Serial.printf("Relay %d -> %s (via %s)\n", pump, state ? "ON" : "OFF", source.c_str());
  statusChanged = true;
}

// ============================================================
// KONTROL OTOMATIS
// ============================================================
void autoControl() {
  // Perbandingan menggunakan float
  bool shouldRelay1 = (soil1Persen > 60.0) || (soil2Persen > 60.0);
  bool shouldRelay2 = (waterPercent < 20.0);
  setPump(1, shouldRelay1, "AUTO");
  setPump(2, shouldRelay2, "AUTO");
}

// ============================================================
// BACA SENSOR (dengan soil float dan level pakai TANK_T)
// ============================================================
void bacaSensor() {
  // Suhu
  float rawTemp = dht.readTemperature();
  if (!isnan(rawTemp)) {
    float maTemp = movingAverage(rawTemp);
    suhu = updateEMA(maTemp) + TEMP_OFFSET;
  } else {
    Serial.println("DHT11 error, retain previous temp");
  }

  // Soil — mapping ke rentang 0-1000 lalu bagi 10 untuk 1 desimal
  int raw1 = analogRead(SOIL1_PIN);
  int raw2 = analogRead(SOIL2_PIN);
  soil1Persen = constrain(map(raw1, SOIL1_DRY, SOIL1_WET, 0, 1000), 0, 1000) / 10.0;
  soil2Persen = constrain(map(raw2, SOIL2_DRY, SOIL2_WET, 0, 1000), 0, 1000) / 10.0;

  // Jarak (ultrasonik)
  float rawDist = readDistance();
  if (rawDist >= 2.0 && rawDist <= MAX_DIST) {
    float correctedDist = rawDist + DIST_OFFSET;
    if (firstDistReading) {
      filteredDist = correctedDist;
      firstDistReading = false;
    } else {
      filteredDist = DIST_ALPHA * correctedDist + (1.0 - DIST_ALPHA) * filteredDist;
    }
    float waterHeight = constrain(DIST_EMPTY - filteredDist, 0.0, TANK_T);
    waterPercent = (waterHeight / TANK_T) * 100.0;   // pakai TANK_T
    levelAirCm = waterHeight;
  }

  // Debug dengan 1 desimal
  Serial.println("===== SENSOR =====");
  Serial.printf("Suhu: %.1f °C\n", suhu);
  Serial.printf("Soil1: %.1f%%, Soil2: %.1f%%\n", soil1Persen, soil2Persen);
  Serial.printf("Level: %.1f cm (%.1f%%)\n", levelAirCm, waterPercent);
  Serial.printf("Relay1: %s, Relay2: %s\n", relay1State?"ON":"OFF", relay2State?"ON":"OFF");
}

// ============================================================
// FILTER SUHU
// ============================================================
float movingAverage(float dataBaru) {
  bufferSuhu[bufferIndex] = dataBaru;
  bufferIndex++;
  if (bufferIndex >= WINDOW_SIZE) { bufferIndex = 0; bufferPenuh = true; }
  int n = bufferPenuh ? WINDOW_SIZE : bufferIndex;
  float total = 0;
  for (int i = 0; i < n; i++) total += bufferSuhu[i];
  return total / n;
}

float updateEMA(float input) {
  if (!emaInit) { emaSuhu = input; emaInit = true; }
  else emaSuhu = EMA_ALPHA * input + (1.0 - EMA_ALPHA) * emaSuhu;
  return emaSuhu;
}

// ============================================================
// BACA JARAK
// ============================================================
float getSpeedOfSound(float tempC) { return 331.3 + 0.606 * tempC; }

float readDistance() {
  const int OVERSAMPLE = 3, MEDIAN_ITER = 7;
  unsigned long sum = 0;
  int valid = 0;
  for (int i = 0; i < OVERSAMPLE; i++) {
    unsigned int uS = sonar.ping_median(MEDIAN_ITER);
    if (uS > 0) { sum += uS; valid++; }
  }
  if (valid == 0) return -1.0;
  float avgUs = (float)sum / valid;
  float speed = getSpeedOfSound(emaSuhu);
  return avgUs * speed / 20000.0;
}

// ============================================================
// KIRIM DATA KE DWIN (sesuai 1 desimal dan TANK_T)
// ============================================================
void updateDWIN() {
  unsigned long now = millis();

  if (dwinState == IDLE) {
    // Suhu: 1 desimal
    int suhuInt = (int)(suhu * 10);
    paketSuhu[6] = highByte(suhuInt);
    paketSuhu[7] = lowByte(suhuInt);

    // Soil1 & Soil2: 1 desimal
    int soil1Val = (int)(soil1Persen * 10);
    paketSoil1[6] = highByte(soil1Val);
    paketSoil1[7] = lowByte(soil1Val);

    int soil2Val = (int)(soil2Persen * 10);
    paketSoil2[6] = highByte(soil2Val);
    paketSoil2[7] = lowByte(soil2Val);

    // Level Air: pakai TANK_T (21 cm) agar sama dengan MQTT
    int levelPersen = constrain((int)((levelAirCm / TANK_T) * 100), 0, 100);
    int levelVal = levelPersen * 10;   // 1 desimal
    paketLevelAir[6] = highByte(levelVal);
    paketLevelAir[7] = lowByte(levelVal);

    dwinState = SEND_SUHU;
    lastDwinSendTime = now;
  }

  if (now - lastDwinSendTime >= DWIN_SEND_INTERVAL) {
    switch (dwinState) {
      case SEND_SUHU:
        DWIN_SERIAL.write(paketSuhu, 8);
        dwinState = SEND_SOIL1;
        lastDwinSendTime = now;
        break;
      case SEND_SOIL1:
        DWIN_SERIAL.write(paketSoil1, 8);
        dwinState = SEND_SOIL2;
        lastDwinSendTime = now;
        break;
      case SEND_SOIL2:
        DWIN_SERIAL.write(paketSoil2, 8);
        dwinState = SEND_LEVELAIR;
        lastDwinSendTime = now;
        break;
      case SEND_LEVELAIR:
        DWIN_SERIAL.write(paketLevelAir, 8);
        dwinState = DONE;
        lastDwinSendTime = now;
        break;
      case DONE:
        // tidak ada aksi
        break;
      default:
        dwinState = IDLE;
        break;
    }
  }
}

// ============================================================
// PARSER DWIN (MENERIMA TOMBOL) - TIDAK DIUBAH
// ============================================================
void parseDWIN() {
  if (DWIN_SERIAL.available()) {
    delay(20);

    int len = 0;
    unsigned char Buffer[20];

    while (DWIN_SERIAL.available() && len < 20) {
      Buffer[len++] = DWIN_SERIAL.read();
    }

    if (len > 0) {
      Serial.print("RX : ");
      for (int i = 0; i < len; i++) {
        Serial.print(Buffer[i], HEX);
        Serial.print(" ");
      }
      Serial.println();

      // MOTOR1
      if (len >= 9 && Buffer[4] == 0x65) {
        if (controlMode == MANUAL) {
          if (Buffer[8] == 1) {
            setPump(1, true, "DWIN");
          } else {
            setPump(1, false, "DWIN");
          }
        } else {
          Serial.println("Mode AUTO - DWIN Relay1 diabaikan.");
        }
      }

      // MOTOR2
      if (len >= 9 && Buffer[4] == 0x66) {
        if (controlMode == MANUAL) {
          if (Buffer[8] == 1) {
            setPump(2, true, "DWIN");
          } else {
            setPump(2, false, "DWIN");
          }
        } else {
          Serial.println("Mode AUTO - DWIN Relay2 diabaikan.");
        }
      }
    }
  }
}

// ============================================================
// PUBLISH STATUS KE MQTT (dengan soil float dan level %)
// ============================================================
void publishStatus() {
  if (!mqtt.connected()) return;

  char payload[200];
  snprintf(payload, sizeof(payload),
           "{\"temp_C\":%.1f,\"soil1_pct\":%.1f,\"soil2_pct\":%.1f,\"level_pct\":%.1f,\"pump1\":%s,\"pump2\":%s,\"mode\":\"%s\"}",
           suhu, soil1Persen, soil2Persen, waterPercent,
           relay1State ? "true" : "false",
           relay2State ? "true" : "false",
           (controlMode == AUTO) ? "auto" : "manual"
          );

  if (mqtt.publish(TOPIC_STATUS, payload)) {
    Serial.print("MQTT published: ");
    Serial.println(payload);
    statusChanged = false;
  } else {
    Serial.println("MQTT publish failed");
  }
}