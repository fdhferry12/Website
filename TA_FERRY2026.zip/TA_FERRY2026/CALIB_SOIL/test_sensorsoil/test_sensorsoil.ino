// Definisi pin sensor
const int SOIL_PIN1 = 34;  // GPIO 34 untuk soil moisture sensor 1
const int SOIL_PIN2 = 35;  // GPIO 35 untuk soil moisture sensor 2

// Variabel kalibrasi sensor 1
int dryValue1 = 0;      // Nilai ADC saat tanah KERING
int wetValue1 = 0;      // Nilai ADC saat tanah BASAH
int currentRaw1 = 0;    // Nilai ADC saat ini
bool calibrated1 = false;

// Variabel kalibrasi sensor 2
int dryValue2 = 0;      // Nilai ADC saat tanah KERING
int wetValue2 = 0;      // Nilai ADC saat tanah BASAH
int currentRaw2 = 0;    // Nilai ADC saat ini
bool calibrated2 = false;

// Status kalibrasi
bool isCalibrating = true;

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("\n========================================");
  Serial.println("SOIL MOISTURE SENSOR - CALIBRATION MODE");
  Serial.println("========================================\n");
  Serial.println("PANDUAN KALIBRASI:");
  Serial.println("1. Siapkan sampel tanah KERING dan BASAH");
  Serial.println("2. Ikuti menu di bawah untuk kalibrasi");
  Serial.println("3. Pastikan sensor benar-benar tertanam dalam tanah\n");

  pinMode(SOIL_PIN1, INPUT);
  pinMode(SOIL_PIN2, INPUT);

  showMenu();
}

void loop() {
  if (isCalibrating) {
    calibrationMode();
  } else {
    testingMode();
  }
}

void showMenu() {
  Serial.println("========================================");
  Serial.println("MENU KALIBRASI:");
  Serial.println("----------------------------------------");
  Serial.println("SENSOR 1 (GPIO 34):");
  Serial.println("  'd' = Simpan nilai TANAH KERING");
  Serial.println("  'w' = Simpan nilai TANAH BASAH");
  Serial.println("----------------------------------------");
  Serial.println("SENSOR 2 (GPIO 35):");
  Serial.println("  'j' = Simpan nilai TANAH KERING");
  Serial.println("  'k' = Simpan nilai TANAH BASAH");
  Serial.println("----------------------------------------");
  Serial.println("KONTROL:");
  Serial.println("  't' = Mulai mode TESTING");
  Serial.println("  'r' = Reset semua kalibrasi");
  Serial.println("========================================\n");
  
  // Tampilkan status kalibrasi saat ini
  printCalibrationStatus();
}

void printCalibrationStatus() {
  Serial.println("STATUS KALIBRASI SAAT INI:");
  Serial.print("Sensor 1 - KERING: ");
  Serial.print(dryValue1 > 0 ? String(dryValue1) : "Belum diisi");
  Serial.print(" | BASAH: ");
  Serial.println(wetValue1 > 0 ? String(wetValue1) : "Belum diisi");
  Serial.print("Sensor 2 - KERING: ");
  Serial.print(dryValue2 > 0 ? String(dryValue2) : "Belum diisi");
  Serial.print(" | BASAH: ");
  Serial.println(wetValue2 > 0 ? String(wetValue2) : "Belum diisi");
  Serial.println();
}

void calibrationMode() {
  // Baca nilai realtime sensor
  currentRaw1 = analogRead(SOIL_PIN1);
  currentRaw2 = analogRead(SOIL_PIN2);
  
  // Tampilkan nilai realtime
  Serial.print("S1 Raw: ");
  Serial.print(currentRaw1);
  Serial.print(" | S2 Raw: ");
  Serial.println(currentRaw2);

  if (Serial.available() > 0) {
    char command = Serial.read();
    
    // Buang karakter newline
    if (command == '\n' || command == '\r') return;

    switch (command) {
      case 'd':
      case 'D': {
        Serial.println("\n>>> KALIBRASI SENSOR 1 - TANAH KERING");
        Serial.println("Pastikan sensor tertanam di tanah KERING!");
        dryValue1 = readStableValue(SOIL_PIN1);
        Serial.print("✓ Nilai KERING tersimpan: ");
        Serial.println(dryValue1);
        printCalibrationStatus();
        break;
      }

      case 'w':
      case 'W': {
        Serial.println("\n>>> KALIBRASI SENSOR 1 - TANAH BASAH");
        Serial.println("Pastikan sensor tertanam di tanah BASAH!");
        wetValue1 = readStableValue(SOIL_PIN1);
        Serial.print("✓ Nilai BASAH tersimpan: ");
        Serial.println(wetValue1);
        printCalibrationStatus();
        break;
      }

      case 'j':
      case 'J': {
        Serial.println("\n>>> KALIBRASI SENSOR 2 - TANAH KERING");
        Serial.println("Pastikan sensor tertanam di tanah KERING!");
        dryValue2 = readStableValue(SOIL_PIN2);
        Serial.print("✓ Nilai KERING tersimpan: ");
        Serial.println(dryValue2);
        printCalibrationStatus();
        break;
      }

      case 'k':
      case 'K': {
        Serial.println("\n>>> KALIBRASI SENSOR 2 - TANAH BASAH");
        Serial.println("Pastikan sensor tertanam di tanah BASAH!");
        wetValue2 = readStableValue(SOIL_PIN2);
        Serial.print("✓ Nilai BASAH tersimpan: ");
        Serial.println(wetValue2);
        printCalibrationStatus();
        break;
      }

      case 't':
      case 'T': {
        // Validasi kalibrasi
        bool s1ok = (dryValue1 > 0 && wetValue1 > 0 && dryValue1 > wetValue1);
        bool s2ok = (dryValue2 > 0 && wetValue2 > 0 && dryValue2 > wetValue2);
        
        if (s1ok) calibrated1 = true;
        if (s2ok) calibrated2 = true;

        if (calibrated1 || calibrated2) {
          Serial.println("\n========================================");
          Serial.println("✅ KALIBRASI SELESAI!");
          Serial.println("========================================");
          if (calibrated1) {
            Serial.print("Sensor 1 - Dry: ");
            Serial.print(dryValue1);
            Serial.print(" | Wet: ");
            Serial.println(wetValue1);
            Serial.print("Range: ");
            Serial.println(dryValue1 - wetValue1);
          } else {
            Serial.println("⚠ Sensor 1: Kalibrasi tidak valid!");
          }
          if (calibrated2) {
            Serial.print("Sensor 2 - Dry: ");
            Serial.print(dryValue2);
            Serial.print(" | Wet: ");
            Serial.println(wetValue2);
            Serial.print("Range: ");
            Serial.println(dryValue2 - wetValue2);
          } else {
            Serial.println("⚠ Sensor 2: Kalibrasi tidak valid!");
          }
          Serial.println("\n🔄 Memasuki TESTING MODE...\n");
          isCalibrating = false;
          delay(2000);
        } else {
          Serial.println("\n❌ KALIBRASI BELUM LENGKAP!");
          Serial.println("Pastikan kedua sensor sudah dikalibrasi dengan:");
          Serial.println("- Nilai KERING > Nilai BASAH");
          Serial.println("- Kedua nilai tidak 0\n");
          showMenu();
        }
        break;
      }

      case 'r':
      case 'R': {
        // Reset semua kalibrasi
        dryValue1 = 0; 
        wetValue1 = 0; 
        calibrated1 = false;
        dryValue2 = 0; 
        wetValue2 = 0; 
        calibrated2 = false;
        isCalibrating = true;
        Serial.println("\n🔄 SEMUA KALIBRASI DI-RESET!");
        Serial.println("Mulai kalibrasi dari awal.\n");
        showMenu();
        break;
      }

      default:
        // Jika command tidak dikenal
        if (command != '\n' && command != '\r') {
          Serial.print("❌ Command '");
          Serial.print(command);
          Serial.println("' tidak dikenal!");
          showMenu();
        }
        break;
    }
  }

  delay(500);
}

void printSensorStatus(int pin, int raw, int dry, int wet, const char* label) {
  Serial.print(label);
  Serial.print(" | Raw: ");
  Serial.print(raw);
  
  if (dry > 0 && wet > 0 && dry > wet) {
    // Konversi ke persentase kelembaban (0% = kering, 100% = basah)
    int moisture = map(raw, dry, wet, 0, 100);
    moisture = constrain(moisture, 0, 100);
    
    Serial.print(" | Moisture: ");
    Serial.print(moisture);
    Serial.print("% | Status: ");
    
    // Klasifikasi tingkat kelembaban
    if (moisture >= 80) {
      Serial.print("🌊 SANGAT BASAH");
    } else if (moisture >= 60) {
      Serial.print("💧 BASAH");
    } else if (moisture >= 40) {
      Serial.print("💦 LEMBAB");
    } else if (moisture >= 20) {
      Serial.print("🏜️ KERING");
    } else {
      Serial.print("🔥 SANGAT KERING");
    }
  } else {
    Serial.print(" | ⚠ Belum dikalibrasi dengan benar");
  }
  Serial.println();
}

void testingMode() {
  // Baca nilai sensor
  currentRaw1 = analogRead(SOIL_PIN1);
  currentRaw2 = analogRead(SOIL_PIN2);

  Serial.println("========================================");
  Serial.println("📊 SOIL MOISTURE TESTING MODE");
  Serial.println("========================================");
  
  printSensorStatus(SOIL_PIN1, currentRaw1, dryValue1, wetValue1, "Sensor 1 (GPIO 34)");
  printSensorStatus(SOIL_PIN2, currentRaw2, dryValue2, wetValue2, "Sensor 2 (GPIO 35)");
  
  Serial.println("========================================");
  Serial.println("Ketik 'r' untuk kalibrasi ulang");
  Serial.println("========================================\n");

  // Cek perintah dari serial
  if (Serial.available() > 0) {
    char command = Serial.read();
    if (command == 'r' || command == 'R') {
      // Reset ke mode kalibrasi
      dryValue1 = 0; 
      wetValue1 = 0; 
      calibrated1 = false;
      dryValue2 = 0; 
      wetValue2 = 0; 
      calibrated2 = false;
      isCalibrating = true;
      Serial.println("\n🔄 Kembali ke MODE KALIBRASI...\n");
      showMenu();
      delay(1000);
    }
  }

  delay(2000); // Update setiap 2 detik
}

int readStableValue(int pin) {
  Serial.print("📡 Membaca nilai sensor");
  const int samples = 15;
  const int delayMs = 200;
  long sum = 0;
  int minVal = 4095;
  int maxVal = 0;
  
  for (int i = 0; i < samples; i++) {
    int val = analogRead(pin);
    sum += val;
    if (val < minVal) minVal = val;
    if (val > maxVal) maxVal = val;
    Serial.print(".");
    delay(delayMs);
  }
  
  int stableValue = sum / samples;
  Serial.println(" ✅");
  
  // Tampilkan statistik pembacaan
  Serial.print("   Min: ");
  Serial.print(minVal);
  Serial.print(" | Max: ");
  Serial.print(maxVal);
  Serial.print(" | Avg: ");
  Serial.println(stableValue);
  Serial.print("   Range: ");
  Serial.println(maxVal - minVal);
  
  return stableValue;
}