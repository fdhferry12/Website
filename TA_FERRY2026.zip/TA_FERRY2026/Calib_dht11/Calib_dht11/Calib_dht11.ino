#include <DHT.h>

#define DHTPIN 25
#define DHTTYPE DHT11
#define JUMLAH_SAMPEL_KALIBRASI 10
#define WINDOW_SIZE 10   // jumlah data moving average
#define SUHU_PEMBANDING 28.5  // GANTI NILAI INI SESUAI KEBUTUHAN

DHT dht(DHTPIN, DHTTYPE);

float bufferSuhu[WINDOW_SIZE];
int bufferIndex = 0;
bool bufferPenuh = false;

float alpha = 0.15;      // EMA, makin kecil makin halus
float emaSuhu = 0.0;
bool emaInitialized = false;

float suhuPembanding = SUHU_PEMBANDING;  // menggunakan nilai dari define
float offsetKalibrasi = 0.0;
bool kalibrasiSelesai = false;

// Inisialisasi buffer filter
void initBuffer(float nilaiAwal) {
  for (int i = 0; i < WINDOW_SIZE; i++) {
    bufferSuhu[i] = nilaiAwal;
  }
  bufferIndex = 0;
  bufferPenuh = true;
}

// Moving Average
float movingAverage(float dataBaru) {
  bufferSuhu[bufferIndex] = dataBaru;
  bufferIndex++;

  if (bufferIndex >= WINDOW_SIZE) {
    bufferIndex = 0;
    bufferPenuh = true;
  }

  int jumlahData = bufferPenuh ? WINDOW_SIZE : bufferIndex;
  float total = 0.0;

  for (int i = 0; i < jumlahData; i++) {
    total += bufferSuhu[i];
  }

  return total / jumlahData;
}

// EMA Filter
float updateEMA(float input) {
  if (!emaInitialized) {
    emaSuhu = input;
    emaInitialized = true;
  } else {
    emaSuhu = alpha * input + (1.0 - alpha) * emaSuhu;
  }
  return emaSuhu;
}

// Kalibrasi 10 sampel
bool kalibrasi10Sampel() {
  float total = 0.0;

  Serial.println("\nMengambil 10 sampel suhu untuk kalibrasi...");

  for (int i = 0; i < JUMLAH_SAMPEL_KALIBRASI; i++) {
    float suhu = dht.readTemperature();

    if (isnan(suhu)) {
      Serial.println("Gagal membaca DHT11 saat kalibrasi.");
      return false;
    }

    total += suhu;
    delay(1500);
  }

  float rataSuhu = total / JUMLAH_SAMPEL_KALIBRASI;
  offsetKalibrasi = suhuPembanding - rataSuhu;
  kalibrasiSelesai = true;

  Serial.println("Kalibrasi selesai.");
  Serial.print("Offset kalibrasi = ");
  Serial.print(offsetKalibrasi, 2);
  Serial.println(" C\n");

  return true;
}

void tampilPetunjuk() {
  Serial.println("=========== DHT11 SUHU FINAL ===========");
  Serial.print("Suhu pembanding yang digunakan: ");
  Serial.print(suhuPembanding, 2);
  Serial.println(" C");
  Serial.println("Program akan otomatis melakukan kalibrasi");
  Serial.println("========================================\n");
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  delay(1500);

  float suhuAwal = dht.readTemperature();
  if (!isnan(suhuAwal)) {
    initBuffer(suhuAwal);
    emaSuhu = suhuAwal;
    emaInitialized = true;
  }

  tampilPetunjuk();

  Serial.println("Memulai kalibrasi otomatis...");
  kalibrasi10Sampel();
}

void loop() {
  // Bagian untuk input serial masih tersedia jika ingin mengubah secara manual
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();

    if (input.startsWith("k") || input.startsWith("K")) {
      String nilai = input.substring(1);
      suhuPembanding = nilai.toFloat();

      Serial.print("\nSuhu pembanding diubah menjadi = ");
      Serial.print(suhuPembanding, 2);
      Serial.println(" C");

      kalibrasi10Sampel();
    }
  }

  float suhu = dht.readTemperature();

  if (isnan(suhu)) {
    Serial.println("Gagal membaca DHT11!");
    delay(2000);
    return;
  }

  // Filter Moving Average
  float suhuMA = movingAverage(suhu);

  // Kalibrasi offset
  float suhuKalibrasi = suhuMA;
  if (kalibrasiSelesai) {
    suhuKalibrasi = suhuMA + offsetKalibrasi;
  }

  // Filter EMA 
  float suhuFinal = updateEMA(suhuKalibrasi);

  Serial.print("Suhu Final: ");
  Serial.print(suhuFinal, 2);
  Serial.println(" C");

  delay(2000);
}