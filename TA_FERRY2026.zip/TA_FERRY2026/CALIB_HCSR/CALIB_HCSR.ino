#include <NewPing.h>

#define TRIG_PIN 19
#define ECHO_PIN 18
#define MAX_DIST 50
#define OVERSAMPLE 3
uint8_t medianIter = 7;

NewPing sonar(TRIG_PIN, ECHO_PIN, MAX_DIST);

const float TANK_P = 35;
const float TANK_L = 26.8;
const float TANK_T = 21;
const float VOL_PER_CM = (TANK_P * TANK_L) / 1000.0;
const float TANK_CAPACITY = VOL_PER_CM * TANK_T;

float distEmpty = 26.2;
float temperature = 28.0;
float filteredDist = 0;
bool firstReading = true;
const float ALPHA = 0.1;

float getSpeedOfSound() {
  return 331.3 + 0.606 * temperature;
}

float readDistance() {
  unsigned long sum = 0;
  int valid = 0;
  for (int i = 0; i < OVERSAMPLE; i++) {
    unsigned int uS = sonar.ping_median(medianIter);
    if (uS > 0) { sum += uS; valid++; }
  }
  if (valid == 0) return -1;
  float avgUs = (float)sum / valid;
  float speed = getSpeedOfSound();
  return avgUs * speed / 20000.0;
}

void setup() {
  Serial.begin(115200);

  Serial.println("=== Monitor Tandon Air ===");
  Serial.print("Dimensi: ");
  Serial.print(TANK_P); Serial.print(" x ");
  Serial.print(TANK_L); Serial.print(" x ");
  Serial.print(TANK_T); Serial.println(" cm");
  Serial.print("Kapasitas: "); Serial.print(TANK_CAPACITY, 2); Serial.println(" L");
  Serial.print("Volume per cm: "); Serial.print(VOL_PER_CM, 4); Serial.println(" L/cm");
  Serial.print("Jarak sensor ke dasar (distEmpty): "); Serial.print(distEmpty); Serial.println(" cm");
  Serial.print("Kecepatan suara: "); Serial.print(getSpeedOfSound()); Serial.println(" m/s");
  Serial.println();
  Serial.println("Perintah:");
  Serial.println("  e<spasi>jarak -> set jarak sensor ke dasar tangki (default 26.2)");
  Serial.println("  t<spasi>suhu  -> set suhu ruang utk kompensasi (default 28 C)");
  Serial.println("  m<spasi>n     -> set median iterasi (default 7)");
  Serial.println();
}

void loop() {
  if (Serial.available() > 0) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) return;

    char first = line.charAt(0);

    if (first == 'e' || first == 'E') {
      float val = line.substring(1).toFloat();
      if (val > 0) { distEmpty = val; Serial.print("distEmpty: "); Serial.println(distEmpty); }
      else Serial.println("Gunakan: e<spasi>26.2");
    } else if (first == 't' || first == 'T') {
      float val = line.substring(1).toFloat();
      if (val > -50 && val < 100) {
        temperature = val;
        Serial.print("Suhu: "); Serial.print(temperature); Serial.println(" C");
        Serial.print("Kecepatan suara: "); Serial.print(getSpeedOfSound()); Serial.println(" m/s");
      } else Serial.println("Gunakan: t<spasi>28");
    } else if (first == 'm' || first == 'M') {
      int val = line.substring(1).toInt();
      if (val >= 1 && val <= 50) {
        medianIter = val;
        Serial.print("Median iterasi: "); Serial.println(medianIter);
      } else Serial.println("Gunakan: m<spasi>7");
    } else {
      Serial.println("Perintah tidak dikenal.");
    }
    return;
  }

  float rawDist = readDistance();
  if (rawDist < 0) {
    Serial.println("Error: no echo");
    delay(200);
    return;
  }

  if (rawDist < 2.0) {
    Serial.println("Warning: blind zone < 2 cm");
    delay(200);
    return;
  }

  if (firstReading) { filteredDist = rawDist; firstReading = false; }
  else { filteredDist = ALPHA * rawDist + (1.0 - ALPHA) * filteredDist; }

  // Tinggi air = jarak sensor ke dasar - jarak sensor ke permukaan air sekarang
  float waterHeight = constrain(distEmpty - filteredDist, 0, TANK_T);
  float volume = waterHeight * VOL_PER_CM;
  float percent = (waterHeight / TANK_T) * 100.0;

  Serial.print("Raw: "); Serial.print(rawDist, 2);
  Serial.print(" cm | Filtered: "); Serial.print(filteredDist, 2);
  Serial.print(" cm | Air: "); Serial.print(waterHeight, 2);
  Serial.print(" cm | "); Serial.print(volume, 2);
  Serial.print(" L | "); Serial.print(percent, 1);
  Serial.println("%");

  delay(1);
}