#include <DHT.h>

#define DHTPIN 25
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);
HardwareSerial dwin(1);

const byte rxPin = 16;
const byte txPin = 17;

// SENSOR
#define SOIL1_PIN 34
#define SOIL2_PIN 35

#define TRIG_PIN 19
#define ECHO_PIN 18

// RELAY ACTIVE LOW
#define MOTOR1 27
#define MOTOR2 26

// VP DWIN
#define VP_SUHU      0x61
#define VP_SOIL1     0x62
#define VP_SOIL2     0x63
#define VP_LEVELAIR  0x64

// BUFFER KIRIM DWIN
unsigned char Suhu[8] =
{
  0x5A,0xA5,0x05,0x82,
  VP_SUHU,0x00,
  0x00,0x00
};

unsigned char Soil1[8] =
{
  0x5A,0xA5,0x05,0x82,
  VP_SOIL1,0x00,
  0x00,0x00
};

unsigned char Soil2[8] =
{
  0x5A,0xA5,0x05,0x82,
  VP_SOIL2,0x00,
  0x00,0x00
};

unsigned char LevelAir[8] =
{
  0x5A,0xA5,0x05,0x82,
  VP_LEVELAIR,0x00,
  0x00,0x00
};

// BACA ULTRASONIK
float readLevelAir()
{
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  if(duration == 0)
    return 0;

  return duration * 0.0343 / 2.0;
}

void setup()
{
  Serial.begin(115200);

  dht.begin();

  dwin.begin(115200, SERIAL_8N1, rxPin, txPin);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(MOTOR1, OUTPUT);
  pinMode(MOTOR2, OUTPUT);

  digitalWrite(MOTOR1, HIGH);
  digitalWrite(MOTOR2, HIGH);

  Serial.println("SYSTEM READY");
}

void loop()
{
  relay_control();

  static unsigned long lastSensor = 0;

  if (millis() - lastSensor >= 1000)
  {
    lastSensor = millis();
    sensor_data();
  }
}

// KIRIM DATA SENSOR KE DWIN
void sensor_data()
{
  float temp = dht.readTemperature();

  if (isnan(temp))
  {
    Serial.println("DHT11 ERROR");
    return;
  }

  int suhu = (int)temp;

  int soil1Raw = analogRead(SOIL1_PIN);
  int soil2Raw = analogRead(SOIL2_PIN);

  int soil1Persen = map(soil1Raw, 4095, 1200, 0, 100);
  int soil2Persen = map(soil2Raw, 4095, 1200, 0, 100);

  soil1Persen = constrain(soil1Persen, 0, 100);
  soil2Persen = constrain(soil2Persen, 0, 100);

  int levelAir = (int)readLevelAir();

  Serial.println("========================");
  Serial.print("Suhu      : ");
  Serial.println(suhu);

  Serial.print("Soil 1    : ");
  Serial.print(soil1Persen);
  Serial.println("%");

  Serial.print("Soil 2    : ");
  Serial.print(soil2Persen);
  Serial.println("%");

  Serial.print("Level Air : ");
  Serial.print(levelAir);
  Serial.println(" cm");

  // SUHU
  Suhu[6] = highByte(suhu);
  Suhu[7] = lowByte(suhu);
  dwin.write(Suhu, 8);

  delay(10);

  // SOIL1
  Soil1[6] = highByte(soil1Persen);
  Soil1[7] = lowByte(soil1Persen);
  dwin.write(Soil1, 8);

  delay(10);

  // SOIL2
  Soil2[6] = highByte(soil2Persen);
  Soil2[7] = lowByte(soil2Persen);
  dwin.write(Soil2, 8);

  delay(10);

  // LEVEL AIR
  LevelAir[6] = highByte(levelAir);
  LevelAir[7] = lowByte(levelAir);
  dwin.write(LevelAir, 8);
}

// KONTROL RELAY DARI DWIN
void relay_control()
{
  if (dwin.available())
  {
    delay(20);

    int len = 0;
    unsigned char Buffer[20];

    while (dwin.available() && len < 20)
    {
      Buffer[len++] = dwin.read();
    }

    Serial.print("RX : ");

    for (int i = 0; i < len; i++)
    {
      Serial.print(Buffer[i], HEX);
      Serial.print(" ");
    }

    Serial.println();

    // MOTOR1
    if (len >= 9 && Buffer[4] == 0x65)
    {
      if (Buffer[8] == 1)
      {
        digitalWrite(MOTOR1, LOW);
        Serial.println("MOTOR1 ON");
      }
      else
      {
        digitalWrite(MOTOR1, HIGH);
        Serial.println("MOTOR1 OFF");
      }
    }

    // MOTOR2
    if (len >= 9 && Buffer[4] == 0x66)
    {
      if (Buffer[8] == 1)
      {
        digitalWrite(MOTOR2, LOW);
        Serial.println("MOTOR2 ON");
      }
      else
      {
        digitalWrite(MOTOR2, HIGH);
        Serial.println("MOTOR2 OFF");
      }
    }
  }
}