#include <WiFi.h>
#include <PubSubClient.h>
#include <NewPing.h>
#include <DHT.h>

// ==================== PIN ====================
#define TRIG_PIN   19
#define ECHO_PIN   18
#define MAX_DIST   50

#define DHTPIN     25
#define DHTTYPE    DHT11

#define SOIL_PIN1  34
#define SOIL_PIN2  35

#define RELAY1     27
#define RELAY2     26

// ==================== WIFI ====================
const char* WIFI_SSID     = "nama_wifi_anda";   // <<< GANTI
const char* WIFI_PASSWORD = "password_wifi";    // <<< GANTI

// ==================== MQTT ====================
const char* MQTT_BROKER   = "broker.emqx.io";
const int   MQTT_PORT     = 1883;
const char* MQTT_TOPIC_STATUS = "tandon/status";           // publish data sensor
const char* MQTT_TOPIC_PUMP1  = "tandon/pump1/control";    // subscribe perintah
const char* MQTT_TOPIC_PUMP2  = "tandon/pump2/control";
const char* MQTT_CLIENT   = "ESP32_Greenhouse";

WiFiClient espClient;
PubSubClient mqtt(espClient);

// ==================== OBYEK ====================
NewPing sonar(TRIG_PIN, ECHO_PIN, MAX_DIST);
DHT dht(DHTPIN, DHTTYPE);

// ==================== KALIBRASI TANGKI ====================
const float DIST_EMPTY   = 26.4;
const float DIST_OFFSET  = 1.03;
const float TANK_P       = 35.0;
const float TANK_L       = 26.8;
const float TANK_T       = 21.0;

float filteredDist       = 0.0;
bool firstDistReading    = true;
const float DIST_ALPHA   = 0.1;
uint8_t medianIter       = 7;
#define OVERSAMPLE        3

// ==================== KALIBRASI SUHU ====================
const float TEMP_OFFSET  = -0.1;    // suhu offset (DHT11 28.9 -> 28.8)

// Filter Suhu (MA + EMA)
const int WINDOW_SIZE    = 10;
float bufferSuhu[WINDOW_SIZE];
int bufferIndex          = 0;
bool bufferPenuh         = false;
float emaSuhu            = 0.0;
bool emaInit             = false;
const float EMA_ALPHA    = 0.15;

// ==================== KALIBRASI SOIL ====================
const int SOIL1_DRY = 2580, SOIL1_WET = 1650;
const int SOIL2_DRY = 2550, SOIL2_WET = 1550;

// ==================== RELAY STATE ====================
bool pump1 = false;   // false = OFF (HIGH), true = ON (LOW)
bool pump2 = false;

// ==================== TIMING ====================
unsigned long lastPublish = 0;
const unsigned long PUBLISH_INTERVAL = 2000;

// ==================== FUNGSI ====================
float getSpeedOfSound(float tempC);
float readDistance();
float movingAverage(float dataBaru);
float updateEMA(float input);
void connectWiFi();
void connectMQTT();
void publishStatus();
void mqttCallback(char* topic, byte* payload, unsigned int length);
void setPump(int pump, bool state);

// ==================== SETUP ====================
void setup() {
  Serial.begin(115200);
  dht.begin();

  // Relay OFF
  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  digitalWrite(RELAY1, HIGH);
  digitalWrite(RELAY2, HIGH);

  // Inisialisasi filter suhu
  float suhuAwal = dht.readTemperature();
  if (!isnan(suhuAwal)) {
    for (int i = 0; i < WINDOW_SIZE; i++) bufferSuhu[i] = suhuAwal;
    bufferPenuh = true;
    emaSuhu = suhuAwal;
    emaInit = true;
  }

  // WiFi & MQTT
  connectWiFi();
  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  connectMQTT();

  Serial.println("System Ready.");
}

// ==================== LOOP ====================
void loop() {
  if (!mqtt.connected()) {
    connectMQTT();
  }
  mqtt.loop();

  if (millis() - lastPublish >= PUBLISH_INTERVAL) {
    lastPublish = millis();
    publishStatus();
  }
}

// ==================== MQTT CALLBACK ====================
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  message.trim();
  Serial.printf("MQTT received [%s]: %s\n", topic, message.c_str());

  if (String(topic) == MQTT_TOPIC_PUMP1) {
    if (message == "on")  setPump(1, true);
    else if (message == "off") setPump(1, false);
  }
  else if (String(topic) == MQTT_TOPIC_PUMP2) {
    if (message == "on")  setPump(2, true);
    else if (message == "off") setPump(2, false);
  }
}

// ==================== SET POMPA ====================
void setPump(int pump, bool state) {
  if (pump == 1) {
    pump1 = state;
    digitalWrite(RELAY1, state ? LOW : HIGH);
  } else if (pump == 2) {
    pump2 = state;
    digitalWrite(RELAY2, state ? LOW : HIGH);
  }
  publishStatus(); // kirim status terbaru
}

// ==================== PUBLISH DATA (TANPA HUMIDITY) ====================
void publishStatus() {
  // 1. Suhu (tanpa kelembaban)
  float rawTemp = dht.readTemperature();
  float suhuFinal = emaSuhu + TEMP_OFFSET; // fallback
  if (!isnan(rawTemp)) {
    float maTemp = movingAverage(rawTemp);
    suhuFinal = updateEMA(maTemp) + TEMP_OFFSET;
  }

  // 2. Jarak & level air
  float rawDist = readDistance();
  float waterPercent = 0.0;
  if (rawDist >= 2.0 && rawDist <= MAX_DIST) {
    float correctedDist = rawDist + DIST_OFFSET;
    if (firstDistReading) {
      filteredDist = correctedDist;
      firstDistReading = false;
    } else {
      filteredDist = DIST_ALPHA * correctedDist + (1.0 - DIST_ALPHA) * filteredDist;
    }
    float waterHeight = constrain(DIST_EMPTY - filteredDist, 0.0, TANK_T);
    waterPercent = (waterHeight / TANK_T) * 100.0;
  }

  // 3. Soil moisture
  int raw1 = analogRead(SOIL_PIN1);
  int raw2 = analogRead(SOIL_PIN2);
  int moist1 = constrain(map(raw1, SOIL1_DRY, SOIL1_WET, 0, 100), 0, 100);
  int moist2 = constrain(map(raw2, SOIL2_DRY, SOIL2_WET, 0, 100), 0, 100);

  // 4. JSON payload (tanpa humidity_pct)
  char payload[160];
  snprintf(payload, sizeof(payload),
           "{\"temp_C\":%.1f,\"soil1_pct\":%d,\"soil2_pct\":%d,\"level_pct\":%.1f,\"pump1\":%s,\"pump2\":%s}",
           suhuFinal, moist1, moist2, waterPercent,
           pump1 ? "true" : "false", pump2 ? "true" : "false");

  if (mqtt.publish(MQTT_TOPIC_STATUS, payload)) {
    Serial.print("MQTT published: ");
    Serial.println(payload);
  } else {
    Serial.println("MQTT publish failed");
  }
}

// ==================== PEMBACAAN JARAK ====================
float getSpeedOfSound(float tempC) {
  return 331.3 + 0.606 * tempC;
}

float readDistance() {
  unsigned long sum = 0;
  int valid = 0;
  for (int i = 0; i < OVERSAMPLE; i++) {
    unsigned int uS = sonar.ping_median(medianIter);
    if (uS > 0) { sum += uS; valid++; }
  }
  if (valid == 0) return -1.0;
  float avgUs = (float)sum / valid;
  float speed = getSpeedOfSound(emaSuhu);
  return avgUs * speed / 20000.0;
}

// ==================== FILTER SUHU ====================
float movingAverage(float dataBaru) {
  bufferSuhu[bufferIndex] = dataBaru;
  bufferIndex++;
  if (bufferIndex >= WINDOW_SIZE) {
    bufferIndex = 0;
    bufferPenuh = true;
  }
  int n = bufferPenuh ? WINDOW_SIZE : bufferIndex;
  float total = 0.0;
  for (int i = 0; i < n; i++) total += bufferSuhu[i];
  return total / n;
}

float updateEMA(float input) {
  if (!emaInit) {
    emaSuhu = input;
    emaInit = true;
  } else {
    emaSuhu = EMA_ALPHA * input + (1.0 - EMA_ALPHA) * emaSuhu;
  }
  return emaSuhu;
}

// ==================== WIFI & MQTT ====================
void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println(" connected!");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

void connectMQTT() {
  while (!mqtt.connected()) {
    Serial.print("Connecting to MQTT...");
    if (mqtt.connect(MQTT_CLIENT)) {
      Serial.println(" connected");
      mqtt.subscribe(MQTT_TOPIC_PUMP1);
      mqtt.subscribe(MQTT_TOPIC_PUMP2);
    } else {
      Serial.print("failed, rc=");
      Serial.print(mqtt.state());
      Serial.println(", retry in 2s");
      delay(2000);
    }
  }
}